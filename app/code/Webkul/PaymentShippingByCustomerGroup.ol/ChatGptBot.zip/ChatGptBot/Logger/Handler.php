<?php
/**
 * @category   Webkul
 * @package    Webkul_ChatGptBot
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace Webkul\ChatGptBot\Logger;

class Handler extends \Magento\Framework\Logger\Handler\Base
{
    /**
     * @var int
     */
    public $loggerType = Logger::INFO;

    /**
     * @var string
     */
    public $fileName = '/var/log/chatgptbot.log';
}
