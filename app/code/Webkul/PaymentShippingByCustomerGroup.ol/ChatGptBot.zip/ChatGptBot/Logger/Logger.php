<?php
/**
 * @category   Webkul
 * @package    Webkul_ChatGptBot
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace Webkul\ChatGptBot\Logger;

class Logger extends \Monolog\Logger
{
    /**
     * Add Error
     *
     * @param string $error
     */
    public function addError($error)
    {
        $this->error($error);
    }

    /**
     * Add Info
     *
     * @param string $info
     */
    public function addInfo($info)
    {
        $this->info($info);
    }
}
