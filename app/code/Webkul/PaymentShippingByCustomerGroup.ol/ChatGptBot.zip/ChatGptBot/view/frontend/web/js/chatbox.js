define([
    'jquery',
    'uiComponent',
    'ko',
    'mage/storage',
    'mage/template',
    'mage/url',
    'slick',
    'jquery/jquery.cookie'
], function ($, Component, ko, storage, mageTemplate) {
    'use strict';
    var self;
    return Component.extend({
        defaults: {
            template: 'Webkul_ChatGptBot/chatbox'
        },
        initialize: function () {
            this._super();
            this.repTmpl = mageTemplate('#reply_client_template');
            this.resTmpl = mageTemplate('#reply_admin_template');
        },
        showLoader: ko.observable(false),

        /**
         * Get Loader Image
         */
        getLoaderImage: function () {
            return window.chatboxConfig.loaderImage;
        },

        /**
         * Get Loading State
         */
        getLoadingState: function () {
            return "Complete";
        },

        /**
         * Get Admin Image
         */
        getAdminImage: function () {
            console.log(window.chatboxConfig.adminImage);
            return window.chatboxConfig.adminImage;
        },

        /**
         * Get Support Name
         */
        getSupportName: function () {
            return window.chatboxConfig.adminChatName;
        },
        /**
         * Open Chat Window
         */
        _openChatWindow: function (element, event) {
            if ($(event.currentTarget).hasClass('windowOpen')) {
                $(event.currentTarget).removeClass('windowOpen');
                $(event.currentTarget).parents('#chatbox-component').children('.chat').hide();
                $(event.currentTarget).children('#maxi-chat').show();
                $(event.currentTarget).children('#minim-chat').hide();
            } else {
                $(event.currentTarget).addClass('windowOpen');
                $(event.currentTarget).parents('#chatbox-component').children('.chat').show();
                $(event.currentTarget).children('#maxi-chat').hide();
                $(event.currentTarget).children('#minim-chat').show();
                $('.chat-history').trigger('scrollChat');
                this._refreshPopup();
            }
        },

        /**
         * Refresh Popup
         */
        _refreshPopup: function () {
            $('.list-group').each(function () {
                $(this).hide();
            });
            this.showReportBox = false;
            this.showFeedbackBox = false;
            this.showRatingDashboard = false;
            this.imageBoxShow = false;
        },

        /**
         * Is History Avialable
         */
        isHistoryAvialable: function () {
            var chatData = localStorage.getItem("cpt_chat");
            if (typeof(chatData) == "undefined" || chatData == null) {
                var da = [{
                    "changeDate": "true",
                    "image": window.chatboxConfig.adminImage,
                    "sender": "admin",
                    "adminName": "Support",
                    "message" : "Hello, how can i help you ?"
                }];
                localStorage.setItem("cpt_chat", JSON.stringify(da));
            } else {
                return chatData.length !== 0;
            }
            return true;
        },

        /**
         * Get Chat History
         */
        getChatHistory: function () {
            return JSON.parse(localStorage.getItem("cpt_chat"));
        },

        /**
         * Scrolled
         */
        scrolled: function (data, event) {
            var elem = event.target;
            if (elem.scrollTop == 0) {
                $(event.currentTarget).animate({ scrollTop: event.target.scrollHeight });
            }
        },

        /**
         * Get Admin Image
         */
        getProfileImage: function () {
            return window.chatboxConfig.adminImage;
        },

        /**
         * reply by customer to Admin
         */
        reply: function (replyForm) {
            var self = this;
            this._refreshPopup();
            var replyData = {},
                formDataArray = $(replyForm).serializeArray();
            formDataArray.forEach(function (entry) {
                var currentData = entry.value.replace(/\n/g, "<br>");
                currentData = currentData.replace(/<script[^>]*>(?:(?!<\/script>)[^])*<\/script>/g, "");
                replyData[entry.name] = self.replaceURLs(currentData);
            });

            $(replyForm).trigger("reset");
        },

        /**
         * Reply submit by enter key press
         */
        replyByEnter: function (data, event) {
            var self = this;
            this._refreshPopup();
            if (event.which == 13 && !event.shiftKey) {
                var replyData = {};
                if (/<(\/)?\w+/.test($(event.target).val())) {
                    alert({
                        title: $.mage.__('Warning'),
                        content: $.mage.__('HTML tags are not allowed.'),
                        actions: {
                            always: function(){
                                $('#chat-form .type_message').focus();
                            }
                        }
                    });
                    return false;
                }
                var currentData = $(event.target).val().replace(/\n/g, "<br>");
                currentData = self.replaceURLs(currentData);
                currentData = currentData.replace(/<script[^>]*>(?:(?!<\/script>)[^])*<\/script>/g, "");
                var cusChtData = {
                    "changeDate": "true",
                    "image": window.chatboxConfig.adminImage,
                    "sender": "customer",
                    "customerName": "You",
                    "message" : currentData
                };
                var da = JSON.parse(localStorage.getItem("cpt_chat"));
                da.push(cusChtData);
                var repTmpl = this.repTmpl({
                    data: cusChtData
                });
                $(repTmpl).appendTo($('.chat-history'));
                $('.chat-history').animate({ scrollTop: $("#chat_history")[0].scrollHeight });
                localStorage.setItem("cpt_chat", JSON.stringify(da));
                self._responseChatData(currentData);
                $(event.target).val('');
                return false;
            } else if (event.shiftKey && event.keyCode == 13) {
                return true;
            } else {
                return true;
            }
        },

        /**
         * update user chat status
         */
        _responseChatData: function (currentData) {
            let self = this;
            let chatData = {};
            $(".wkaicg-bot-thinking").toggleClass("hide");
            $.ajax({
                url : window.chatboxConfig.chatResUrl,
                data : {'prompt':currentData, 'cpt_chat':localStorage.getItem("cpt_chat")},
                type : 'post',
                success: function (response) {
                    if(response.status == 1) {
                        response.msg = self.replaceURLs(response.msg);
                        var admChtData = {
                            "changeDate": "true",
                            "image": window.chatboxConfig.adminImage,
                            "sender": "admin",
                            "adminName": "System",
                            "message" : response.msg
                        };

                        var da = JSON.parse(localStorage.getItem("cpt_chat"));
                        da.push(admChtData);
                        var resTmpl = self.resTmpl({
                            data: admChtData
                        });
                        $(".wkaicg-bot-thinking").toggleClass("hide");
                        $(resTmpl).appendTo($('.chat-history'));
                        $('.chat-history').animate({scrollTop: $("#chat_history")[0].scrollHeight});
                        localStorage.setItem("cpt_chat", JSON.stringify(da));
                    } else {
                        console.log(response);
                    }
                }
            });
        },
        /**
         * replaceURLs
         */
        replaceURLs: function replaceURLs(message) {
            if (!message) return;
            var urlRegex = /(<img\s[^>]*>|<a(?:\s[^>]*)?>[\s\S]*?<\/a>)|(?:(?:https?|ftp|file):\/\/|www\.|ftp\.)(?:\([-A-Z0-9+&@#\/%=~_|$?!:,.]*\)|[-A-Z0-9+&@#\/%=~_|$?!:,.])*(?:\([-A-Z0-9+&@#\/%=~_|$?!:,.]*\)|[A-Z0-9+&@#\/%=~_|$])/gi;
            return message.replace(urlRegex, function (url, tag) {
                if (tag) return url;
                var hyperlink = url;
                if (!hyperlink.match('^https?:\/\/')) {
                    hyperlink = 'http://' + hyperlink;
                }
                return '<a href="' + hyperlink + '" target="_blank" >' + url + '</a>'
            });
        }
});
});
