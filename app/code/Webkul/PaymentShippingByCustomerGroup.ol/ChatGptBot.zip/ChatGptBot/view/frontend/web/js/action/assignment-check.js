/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_ChatGptBot
 * @author    Webkul
 * @copyright Copyright (c)  Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
define(
    [
        'jquery',
        'Webkul_ChatGptBot/js/model/url-builder',
        'mage/storage',
        'Webkul_ChatGptBot/js/action/start-chat',
        'Webkul_ChatGptBot/js/model/reply',
        'Webkul_ChatGptBot/js/model/manage-rating'
    ],
    function ($, urlBuilder, storage, startChatAction, replyModel, ratingModel) {
        'use strict';

        return function (customerData) {
            var serviceUrl,
                payload;

            /**
             * find available aganet and assign chat.
             */
            serviceUrl = 'rest/V1/chat/assign-check';
            payload = {
                customerId: customerData.customer_id,
                uniqueId: customerData.unique_id,
                receiverId: customerData.receiver_id,
                receiverUniqueId: customerData.receiver_unique_id
            };
            // replyModel.loadingState($.mage.__('Assigning agent for you...'));
            return storage.post(
                serviceUrl,
                JSON.stringify(payload)
            ).fail(
                function (response) {
                    location.reload();
                }
            ).done(
                function (response) {
                    var data = $.parseJSON(response);
                    if (data.same_agent == true) {
                        return true;
                    } else {
                        replyModel.receiverUniqueId(data.agent_unique_id);
                        replyModel.receiverId(data.agent_id);
                        replyModel.receiverName(data.agent_name);
                        replyModel.receiverEmail(data.email);
                        replyModel.agentGoesOff(true);
                        replyModel.agentGoesOffError(data.message);
                        ratingModel.ratingData(data.agentRatings)
                        replyModel.adminStatus(data.agent_status);
                    }
                    return true;
                    /*fullScreenLoader.stopLoader();*/
                }
            );
        };
    }
);
