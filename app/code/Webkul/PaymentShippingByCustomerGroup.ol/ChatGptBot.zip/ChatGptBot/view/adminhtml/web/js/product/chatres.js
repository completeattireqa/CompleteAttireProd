/**
 * @category   Webkul
 * @package    Webkul_ChatGptBot
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
/*jshint jquery:true*/
define([
    'jquery',
    "mage/loader",
    'Magento_Ui/js/modal/alert'
], function ($, loader, alert) {
    'use strict';
    var self;
    $.widget('mage.productChat', {
        _create: function () {
            self = this;
            $("#"+self.options.buttonSelector).on( "click", function() {
               var alerttext = '';
               $.ajax({
                   url: self.options.ajaxCheckUrl,
                   data: {form_key: window.FORM_KEY},
                   type: 'POST',
                   dataType:'JSON',
                   showLoader: true,
                   success: function (response) {
                       if (response.msg) {
                           $('<div>').html(response.msg)
                               .modal({
                                   title: $.mage.__('Attention'),
                                   autoOpen: true,
                                   buttons: [{
                                    text: 'OK',
                                       attr: {
                                           'data-action': 'cancel'
                                       },
                                       'class': 'action-primary',
                                       click: function() {
                                               this.closeModal();
                                           }
                                   }]
                                });
                       } else {
                           if (response.success) {
                               alerttext = '<b>'+$.mage.__('Product export : ')+'</b>'+ response.success+'<br>';
                           } else if (response.error1) {
                               alerttext+='<b>'+$.mage.__('Product already export: ')+'</b>'+ response.error1+'<br>';
                           }
                           $('<div>').html(alerttext)
                               .modal({
                                   title: $.mage.__('Attention'),
                                   autoOpen: true,
                                   buttons: [{
                                    text: 'OK',
                                       attr: {
                                           'data-action': 'cancel'
                                       },
                                       'class': 'action-primary',
                                       click: function() {
                                               this.closeModal();
                                           }
                                   }]
                           });
                       }
                   },
                   error: function(error){
                       $('<div>').html(error)
                           .modal({
                               title: $.mage.__('Attention'),
                               autoOpen: true,
                               buttons: [{
                                text: 'OK',
                                   attr: {
                                       'data-action': 'cancel'
                                   },
                                   'class': 'action-primary',
                                   click: function() {
                                           this.closeModal();
                                       }
                               }]
                           });
                   }
               });
           });
        }
    });
    return $.mage.productChat;
});
