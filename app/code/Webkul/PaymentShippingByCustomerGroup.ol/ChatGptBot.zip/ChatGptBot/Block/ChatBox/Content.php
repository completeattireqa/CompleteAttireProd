<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_ChatGptBot
 * @author    Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\ChatGptBot\Block\ChatBox;

use Magento\Store\Model\ScopeInterface;
use Laminas\Json\Json;

class Content extends \Magento\Framework\View\Element\Template
{
    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $scopeConfig;

    /**
     * @var LayoutSettings
     */
    protected $configProvider;

    /**
     * @var \Webkul\ChatGptBot\Model\ResourceModel\AgentRating\CollectionFactory
     */
    protected $agentRatingCollection;

    /**
     * @var \Magento\Customer\Model\SessionFactory
     */
    protected $customerSession;

    /**
     * @param \Magento\Framework\View\Element\Template\Context $context
     * @param \Webkul\ChatGptBot\Model\ChatDataConfigProvider $configProvider
     * @param array $data
     */
    public function __construct(
        \Magento\Framework\View\Element\Template\Context $context,
        array $data = []
    ) {
        $this->scopeConfig = $context->getScopeConfig();
        parent::__construct($context, $data);
    }

    /**
     * Get Js Layout
     *
     * @return array
     */
    public function getJsLayout()
    {
        $layout = Json::decode(parent::getJsLayout(), Json::TYPE_ARRAY);
        return Json::encode($layout);
    }

    /**
     * Retrieve information from carrier configuration.
     *
     * @param string $field
     *
     * @return void|false|string
     */
    public function getConfigData($field, $group = "general_settings")
    {
        $path = 'chatgptbot/'.$group.'/'.$field;
        return $this->scopeConfig->getValue(
            $path,
            ScopeInterface::SCOPE_STORE,
            $this->_storeManager->getStore()->getId()
        );
    }

    /**
     * Get ChatBox Config
     *
     * @return array
     */
    public function getChatBoxConfig()
    {
        //$configData = $this->configProvider->getConfig();
        $mediaUrl = $this->_storeManager->getStore()->getBaseUrl(\Magento\Framework\UrlInterface::URL_TYPE_MEDIA);
        $configData['sendImage'] = $this->getViewFileUrl('Webkul_ChatGptBot::images/send_message.png');
        $configData['loaderImage'] = $this->getViewFileUrl('Webkul_ChatGptBot::images/loader-2.gif');
        $configData['downloadImage'] = $this->getViewFileUrl('Webkul_ChatGptBot::images/download.png');
        $configData['attachmentImage'] = $this->getViewFileUrl('Webkul_ChatGptBot::images/attachment.png');
        $configData['soundUrl'] = $this->getViewFileUrl('Webkul_ChatGptBot::images/sound/notify.ogg');
        $configData['emojiImagesPath'] = $this->getViewFileUrl('Webkul_ChatGptBot::images/emojis');
        $configData['maxFileSize'] = $this->getConfigData('max_file_size');
        $configData['adminImage'] = $mediaUrl."chatgptbot/".$this->getConfigData('logo', 'chat-window');
        $configData['adminChatName'] = $this->getConfigData('title', 'chat-window');
        $configData['chatResUrl'] = $this->_storeManager->getStore()->getUrl('chatgptbot/index/index');
        return $configData;
    }
}
