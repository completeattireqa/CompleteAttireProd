<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_ChatGptBot
 * @author    Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\ChatGptBot\Controller\Index;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Webkul\ChatGptBot\Logger\Logger;
use Webkul\ChatGptBot\Helper\Data as HelperData;

class Index extends Action
{
    /**
     * @var Magento\Framework\Controller\Result\JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var Webkul\ChatGptBot\Logger\Logger
     */
    private $logger;

    /**
     * @var Webkul\ChatGptBot\Helper\Data
     */
    private $helperData;

    /**
     * @param Context $context
     * @param ProductRepositoryInterface $productRepository
     * @param JsonFactory $resultJsonFactory
     * @param Logger $logger
     * @param HelperData $helperData
     */
    public function __construct(
        Context $context,
        JsonFactory $resultJsonFactory,
        Logger $logger,
        HelperData $helperData,
    ) {
        parent::__construct($context);
        $this->resultJsonFactory = $resultJsonFactory;
        $this->logger = $logger;
        $this->helperData = $helperData;
        $this->jsonHelper = $helperData->getJsonHelper();
    }

    /**
     * EBay Category Sync Controller.
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        try {
            $config = $this->helperData->getConfiguration();
            $resultJson = $this->resultJsonFactory->create();
            $result = [
                "status" => 1,
                "msg" => __('There is nothing to import. All the categories are already imported.')
            ];
            $data = $this->getRequest()->getParams();
            $prompt = [];
            if ($config['enable'] && isset($data['prompt'])) {
                $cptChatData = json_decode($data["cpt_chat"], true);
                foreach ($cptChatData as $value) {
                    if ($value['sender'] == 'customer') {
                        $prompt[] = $value['message'];
                    }
                }
                $openAiObj = $this->helperData->getOpenAI();
                $prompt = implode(", ", $prompt);

                $promptEmbeddingData = $openAiObj->embeddings([
                    "model" => "text-embedding-ada-002",
                    "input" => $prompt
                ]);
                if (!isset($promptEmbeddingData['error'])) {
                    // Save embeddings data
                    $vectorData = $promptEmbeddingData["data"][0]['embedding'];
                    $pineconeClient = $this->helperData->getPineconeClient();
                    $matchInfo = $pineconeClient->query($vectorData);
                    $wkAiCgChatGreetingMessage = "Hello, how i can help you ?";
                    if (isset($matchInfo['data'][0]['id']) || 1) {
                        if (isset($matchInfo['data'][0]['id'])) {
                            $vertexData = explode("-", $matchInfo['data'][0]['id']);
                            $contentForInfo = $this->helperData->getDataAsVertex($vertexData);
                            $content = "Converse as if you were an AI assistant. Answer the question as truthfully as possible using the provided context."
                                    ." Tone: Friendly. , Current context: ".'"'.$this->jsonHelper->jsonEncode($contentForInfo).'"';
                        } else {
                            $content = "Converse as if you were an AI assistant. Answer the question as truthfully as possible using the provided context."
                                    ." Tone: Friendly. , Current context: ".'"'.$prompt.'"';
                        }
                        
                        $wkAiCgChatgptMessages = [];
                        $wkAiCgChatgptMessages[] = [
                            'role' => 'user',
                            'content' => html_entity_decode($content,ENT_QUOTES ,'UTF-8')
                        ];

                        foreach ($cptChatData as $chatThread) {
                            $sender = $chatThread['sender'] == "admin" ? "" : "Human: ";
                            $wkAiCgConversationEndMessages[] =  $sender.$chatThread['message'];
                        }
                        $wkAiCgHumanName = "Human";
                        foreach ($wkAiCgConversationEndMessages as $wkAiCgConversationEndMessage) {
                            $wkAiCgChatgptMessage = $wkAiCgConversationEndMessage;
                            if (strpos($wkAiCgConversationEndMessage, $wkAiCgHumanName.': ') !== false) {
                                $wkAiCgChatgptMessage = str_replace($wkAiCgHumanName.': ','',$wkAiCgChatgptMessage);
                                $wkAiCgChatgptMessage = str_replace("\nAI: ",'',$wkAiCgChatgptMessage);
                                if (!empty($wkAiCgChatgptMessage)) {
                                    $wkAiCgChatgptMessages[] = array('role' => 'user', 'content' => $wkAiCgChatgptMessage);
                                }
                            } else{
                                if (!empty($wkAiCgChatgptMessage)) {
                                    $wkAiCgChatgptMessages[] = array('role' => 'assistant', 'content' => $wkAiCgChatgptMessage);
                                }
                            }
                            $wkAiCgChatGreetingMessage .= "\n" . $wkAiCgConversationEndMessage;
                        }
                        //$prompt = $wkAiCgChatGreetingMessage;
                        $wkAiCgDataRequest = [
                            'model' => 'gpt-3.5-turbo',
                            'messages' => $wkAiCgChatgptMessages,
                            'temperature' => floatval(1),
                            'max_tokens' => intval(128),
                            'frequency_penalty' => floatval(0.01),
                            'presence_penalty' => floatval(0.01),
                            'top_p' => floatval(0.01)
                        ];

                        $chatData = $openAiObj->chat($wkAiCgDataRequest);
                        $result['msg'] = $chatData;
                    } else {
                        $result['msg'] = $matchInfo['data'] ?? __("Please communicate with admin something went wrong.");
                    }
                } else {
                    $result['msg'] = $promptEmbeddingData['error']['message'];
                }

            } else {
                $result['msg'] = __('Please fill the all ChatGpt bot details in configuration and save the configuration.');
            }
            return $resultJson->setData($result);
        } catch (\Exception $e) {
            $this->logger->addError('product import : '.$e->getMessage());
            $result = [
                'status' => 0,
                'msg' => $e->getMessage()
            ];
            return $resultJson->setData($result);
        }
    }
}
