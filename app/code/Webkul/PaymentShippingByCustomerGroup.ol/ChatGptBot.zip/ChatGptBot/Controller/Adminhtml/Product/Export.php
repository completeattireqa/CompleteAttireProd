<?php
/**
 * @category   Webkul
 * @package    Webkul_ChatGptBot
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */

namespace Webkul\ChatGptBot\Controller\Adminhtml\Product;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Webkul\ChatGptBot\Logger\Logger;
use Webkul\ChatGptBot\Helper\Data as HelperData;
use Webkul\ChatGptBot\Helper\OpenAI;

class Export extends Action
{
    /**
     * @var string
     */
    public const ADMIN_RESOURCE = 'Webkul_ChatGptBot::config_export_product';

    /**
     * @var Magento\Framework\Controller\Result\JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var Webkul\ChatGptBot\Logger\Logger
     */
    private $logger;

    /**
     * @var Webkul\ChatGptBot\Helper\Data
     */
    private $helperData;


    /**
     * @param Context $context
     * @param JsonFactory $resultJsonFactory
     * @param Logger $logger
     * @param HelperData $helperData
     */
    public function __construct(
        Context $context,
        JsonFactory $resultJsonFactory,
        Logger $logger,
        HelperData $helperData,
    ) {
        parent::__construct($context);
        $this->resultJsonFactory = $resultJsonFactory;
        $this->logger = $logger;
        $this->helperData = $helperData;
    }

    /**
     * EBay Category Sync Controller.
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        try {
            $config = $this->helperData->getConfiguration();
            $resultJson = $this->resultJsonFactory->create();
            $result['msg'] = __('There is nothing to import. All the categories are already imported.');
            if ($config['enable']) {
                $instance = new OpenAI($config['secret_key']);
                $prompt = '{"prompt":"Company: BHFF Webkul insurance\nProduct: allround insurance\nAd:One stop shop for all your insurance needs!\nSupported:", "completion":" yes"}
{"prompt":"Company: Loft Webkul conversion specialists\nProduct: -\nAd:Straight teeth in weeks!\nSupported:", "completion":" no"}';
                $prompt = "Company: BHFF Webkul insurance\nProduct: allround insurance\nAd:One stop shop for all your insurance needs!\nSupported:";
                $res = $instance->complete(
                     $prompt,
                     100,
                     [
                     "stop" => ["\n"],
                     "temperature" => 0,
                     "frequency_penalty" => 0,
                     "presence_penalty" => 0,
                     "max_tokens" => 100,
                     "top_p" => 1
                     ]
                );
                $result['msg'] = json_encode($res);
            } else {
                $result['msg'] = __('Please fill the all eBay details in configuration and save the configuration.');
            }

            return $resultJson->setData($result);
        } catch (\Exception $e) {
            $this->logger->addError('category import : '.$e->getMessage());
            $result['msg'] = $e->getMessage();
            return $resultJson->setData($result);
        }
    }
}
