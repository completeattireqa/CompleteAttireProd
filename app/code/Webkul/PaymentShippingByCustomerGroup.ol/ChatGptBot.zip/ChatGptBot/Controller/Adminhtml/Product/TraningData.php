<?php
/**
 * @category   Webkul
 * @package    Webkul_ChatGptBot
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */

namespace Webkul\ChatGptBot\Controller\Adminhtml\Product;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Framework\Api\SearchCriteriaInterface;
use Magento\Framework\Api\SearchCriteriaBuilder;
use Magento\Framework\Controller\Result\JsonFactory;
use Magento\Framework\Escaper;
use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory;
use Webkul\ChatGptBot\Logger\Logger;
use Webkul\ChatGptBot\Helper\Data as HelperData;

use Orhanerday\OpenAi\OpenAi as OrhanerdayOpenAi;

class TraningData extends Action
{
    /**
     * @var string
     */
    public const ADMIN_RESOURCE = 'Webkul_ChatGptBot::config_export_product';

    /**
     * @var Magento\Framework\Controller\Result\JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var Webkul\ChatGptBot\Logger\Logger
     */
    private $logger;

    /**
     * @var Webkul\ChatGptBot\Helper\Data
     */
    private $helperData;

    /**
     * @param Context $context
     * @param ProductRepositoryInterface $productRepository
     * @param JsonFactory $resultJsonFactory
     * @param Logger $logger
     * @param HelperData $helperData
     */
    public function __construct(
        Context $context,
        ProductRepositoryInterface $productRepository,
        CollectionFactory $categoryCollectionFactory,
        SearchCriteriaInterface $searchCriteria,
        SearchCriteriaBuilder $searchCriteriaBuilder,
        JsonFactory $resultJsonFactory,
        Escaper $escaper,
        Logger $logger,
        HelperData $helperData,
    ) {
        parent::__construct($context);
        $this->productRepository = $productRepository;
        $this->categoryCollectionFactory = $categoryCollectionFactory;
        $this->searchCriteria = $searchCriteria;
        $this->searchCriteriaBuilder = $searchCriteriaBuilder;
        $this->resultJsonFactory = $resultJsonFactory;
        $this->escaper = $escaper;
        $this->logger = $logger;
        $this->helperData = $helperData;
        $this->jsonHelper = $helperData->getJsonHelper();
    }

    /**
     * EBay Category Sync Controller.
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        try {
            /*$instance = $this->helperData->getOpenAI();
            $prompt = "Price of QG1000117 ?";
            $res = $instance->complete(
                [
                    "prompt" => $prompt,
                    "model" => "text-embedding-ada-002"
                ]
            );
            print_r($res);
            die;*/
            $config = $this->helperData->getConfiguration();
            $resultJson = $this->resultJsonFactory->create();
            $result['msg'] = __('There is nothing to import. All the categories are already imported.');
            if ($config['enable']) {
                $searchCriteria = $this->searchCriteriaBuilder->setPageSize(5)->create();
                $products = $this->productRepository->getList($searchCriteria)->getItems();
                $productData = [];
                $da = "";
                $productText = "";
                $openAiObj = $this->helperData->getOpenAI();//new OrhanerdayOpenAi($config['secret_key']);
                $collectionCat = $this->categoryCollectionFactory->create();
                $collectionCat->addAttributeToSelect('*');
                $collectionCat->addIsActiveFilter();
                foreach ($products as $pro) {
                    $tempCatColl = $collectionCat;
                    $categoryList = $tempCatColl->addAttributeToFilter('entity_id', $pro->getCategoryIds())->getColumnValues('name');
                    $productDataArr = [
                        "Entity Id" => $pro->getEntityId(),
                        "Sku" => $this->escaper->escapeHtml($pro->getSku()),
                        "Status" => 1,
                        "Name" => $this->escaper->escapeHtml($pro->getName()),
                        "Meta Title" => $this->escaper->escapeHtml($pro->getMetaTitle()),
                        "Meta Description" => $this->escaper->escapeHtml($pro->getMetaDescription()),
                        "Description" => $this->escaper->escapeHtml($pro->getDescription()),
                        "Short Description" => $this->escaper->escapeHtml($pro->getShortDescription()),
                        "Meta Keyword" => $this->escaper->escapeHtml($pro->getMetaKeyword()),
                        "Price" => $pro->getPrice(),
                        "Weight" => $pro->getWeight(),
                        "Tax Class" => $this->escaper->escapeHtml($pro->getAttributeText('tax_class_id')),
                        "Condition" => $this->escaper->escapeHtml($pro->getAttributeText('condition')),
                        "Ab01" => $this->escaper->escapeHtml($pro->getAttributeText('ab01')),
                        //"Services" => $pro->getAttributeText('services'),
                        //"Store Id" => $pro->getAttributeText('store_id'),
                        "Category" => $this->escaper->escapeHtml(implode(", ", $categoryList))
                    ];

                    $proCategories = implode(", ", $categoryList);
                    /*echo $wpaicg_content = json_encode($productDataArr);
                    //echo $this->escaper->escapeHtml($wpaicg_content);
                    die;
                    preg_match_all('@\[([^<>&/\[\]\x00-\x20=]++)@', $wpaicg_content, $matches);
                    if ($matches && is_array($matches) && count($matches)) {
                        $pattern = $this->get_shortcode_regex($matches[1]);
                        $wpaicg_content = preg_replace_callback("/$pattern/", 'strip_shortcode_tag', $wpaicg_content);
                    }
                    $wpaicg_content = trim($wpaicg_content);
                    $wpaicg_content = preg_replace("/<((?:style)).*>.*<\/style>/si", ' ',$wpaicg_content);
                    $wpaicg_content = preg_replace("/<((?:script)).*>.*<\/script>/si", ' ',$wpaicg_content);
                    $wpaicg_content = preg_replace('/<a(.*)href="([^"]*)"(.*)>(.*?)<\/a>/i', '$2', $wpaicg_content);
                    $wpaicg_content = strip_tags($wpaicg_content);
                    $wpaicg_content = preg_replace("/(^[\r\n]*|[\r\n]+)[\s\t]*[\r\n]+/", "\n", $wpaicg_content);
                    $wpaicg_content = trim($wpaicg_content);*/

                    //$this->jsonHelper->jsonEncode([json_encode($productDataArr)]);

                    $result = $openAiObj->embeddings([
                        "model" => "text-embedding-ada-002",
                        "input" => $this->jsonHelper->jsonEncode([json_encode($productDataArr)])
                    ]);

                    // Save embeddings data
                    $vectorData = $result["data"][0]['embedding'];
                    $pineconeClient = $this->helperData->getPineconeClient();
                    $pineconeClient->upsert($vectorData, "products", $pro->getEntityId(), $proCategories);

                    $this->helperData->embeddingRecordSave([
                        "content" => $this->jsonHelper->jsonEncode($productDataArr),
                        "token" => $result["usage"]['total_tokens'],
                        "type" => "products",
                        "estimated" => ($result["usage"]['total_tokens'] / 1000) * 0.0004
                    ]);

                }


                //die;
                /*$c_file = curl_file_create(__DIR__ . '/trandata.jsonl');
                $result = $openAiObj->uploadFile([
                            "purpose" => "fine-tune",
                            "file" => $c_file,
                ]);
                $resultD = $this->jsonHelper->jsonDecode($result, true);
                $result = $openAiObj->createFineTune([
                            "training_file" => $resultD["id"],
                            "model" => "ada"
                ]);*/
                /*print_r($result);
                echo "------------------";
                die;*/
                /*$search = $openAiObj->search([
                    'engine' => 'ada',
                    'documents' => ['White House', 'hospital', 'school'],
                    'query' => 'the president',
                ]);*/
                //$files = $openAiObj->listFiles();
                //print_r($files);
                //die;
            //    die;
                $result['msg'] = __('Products data exported for ChatGpt bot successfully.');
            } else {
                $result['msg'] = __('Please fill the all ChatGpt bot details in configuration and save the configuration.');
            }
            return $resultJson->setData($result);
        } catch (\Exception $e) {
            $this->logger->addError('product import : '.$e->getMessage());
            $result['msg'] = $e->getMessage();
            return $resultJson->setData($result);
        }
    }

    public function get_shortcode_regex( $tagnames = null ) {
    	global $shortcode_tags;

    	if ( empty( $tagnames ) ) {
    		$tagnames = array_keys( $shortcode_tags );
    	}
    	$tagregexp = implode( '|', array_map( 'preg_quote', $tagnames ) );

    	// WARNING! Do not change this regex without changing do_shortcode_tag() and strip_shortcode_tag().
    	// Also, see shortcode_unautop() and shortcode.js.

    	// phpcs:disable Squiz.Strings.ConcatenationSpacing.PaddingFound -- don't remove regex indentation
    	return '\\['                             // Opening bracket.
    		. '(\\[?)'                           // 1: Optional second opening bracket for escaping shortcodes: [[tag]].
    		. "($tagregexp)"                     // 2: Shortcode name.
    		. '(?![\\w-])'                       // Not followed by word character or hyphen.
    		. '('                                // 3: Unroll the loop: Inside the opening shortcode tag.
    		.     '[^\\]\\/]*'                   // Not a closing bracket or forward slash.
    		.     '(?:'
    		.         '\\/(?!\\])'               // A forward slash not followed by a closing bracket.
    		.         '[^\\]\\/]*'               // Not a closing bracket or forward slash.
    		.     ')*?'
    		. ')'
    		. '(?:'
    		.     '(\\/)'                        // 4: Self closing tag...
    		.     '\\]'                          // ...and closing bracket.
    		. '|'
    		.     '\\]'                          // Closing bracket.
    		.     '(?:'
    		.         '('                        // 5: Unroll the loop: Optionally, anything between the opening and closing shortcode tags.
    		.             '[^\\[]*+'             // Not an opening bracket.
    		.             '(?:'
    		.                 '\\[(?!\\/\\2\\])' // An opening bracket not followed by the closing shortcode tag.
    		.                 '[^\\[]*+'         // Not an opening bracket.
    		.             ')*+'
    		.         ')'
    		.         '\\[\\/\\2\\]'             // Closing shortcode tag.
    		.     ')?'
    		. ')'
    		. '(\\]?)';                          // 6: Optional second closing brocket for escaping shortcodes: [[tag]].
    	// phpcs:enable
    }

}
