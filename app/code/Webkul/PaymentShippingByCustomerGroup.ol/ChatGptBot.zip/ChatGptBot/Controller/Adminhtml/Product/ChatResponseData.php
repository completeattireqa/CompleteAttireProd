<?php
/**
 * @category   Webkul
 * @package    Webkul_ChatGptBot
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */

namespace Webkul\ChatGptBot\Controller\Adminhtml\Product;

use Magento\Backend\App\Action;
use Magento\Backend\App\Action\Context;
use Magento\Framework\Controller\Result\JsonFactory;
use Webkul\ChatGptBot\Logger\Logger;
use Webkul\ChatGptBot\Helper\Data as HelperData;

class ChatResponseData extends Action
{
    /**
     * @var string
     */
    public const ADMIN_RESOURCE = 'Webkul_ChatGptBot::config_export_product';

    /**
     * @var Magento\Framework\Controller\Result\JsonFactory
     */
    private $resultJsonFactory;

    /**
     * @var Webkul\ChatGptBot\Logger\Logger
     */
    private $logger;

    /**
     * @var Webkul\ChatGptBot\Helper\Data
     */
    private $helperData;

    /**
     * @param Context $context
     * @param ProductRepositoryInterface $productRepository
     * @param JsonFactory $resultJsonFactory
     * @param Logger $logger
     * @param HelperData $helperData
     */
    public function __construct(
        Context $context,
        JsonFactory $resultJsonFactory,
        Logger $logger,
        HelperData $helperData,
    ) {
        parent::__construct($context);
        $this->resultJsonFactory = $resultJsonFactory;
        $this->logger = $logger;
        $this->helperData = $helperData;
        $this->jsonHelper = $helperData->getJsonHelper();
    }

    /**
     * EBay Category Sync Controller.
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        try {
            $config = $this->helperData->getConfiguration();
            $resultJson = $this->resultJsonFactory->create();
            $result['msg'] = __('There is nothing to import. All the categories are already imported.');
            if ($config['enable']) {
                $openAiObj = $this->helperData->getOpenAI();
                $prompt = "Name of HG1000037 ?";

                $result = $openAiObj->embeddings([
                    "model" => "text-embedding-ada-002",
                    "input" => $prompt
                ]);
                // Save embeddings data
                $vectorData = $result["data"][0]['embedding'];
                $pineconeClient = $this->helperData->getPineconeClient();
                $matchInfo = $pineconeClient->query($vectorData);
                $wpaicg_chat_greeting_message = "Hello, Welcome to bot";
                if (isset($matchInfo['data'][0]['id'])) {
                    $vertexData = explode("-", $matchInfo['data'][0]['id']);
                    $contentForInfo = $this->helperData->getDataAsVertex($vertexData);
                    $content = "Converse as if you were an AI assistant. Answer the question as truthfully as possible using the provided context."
                                ." Tone: Friendly. , Current context: ".'"'.$this->jsonHelper->jsonEncode($contentForInfo).'"';
                    $wpaicg_chatgpt_messages = [];
                    $wpaicg_chatgpt_messages[] = [
                        'role' => 'user',
                        'content' => html_entity_decode($content,ENT_QUOTES ,'UTF-8')
                    ];
                    $wpaicg_human_name = "Human";
                    $wpaicg_conversation_end_messages[] = $wpaicg_human_name.': ' . $prompt . "\nAI: ";
                    foreach ($wpaicg_conversation_end_messages as $wpaicg_conversation_end_message) {
                        $wpaicg_chatgpt_message = $wpaicg_conversation_end_message;
                        if(strpos($wpaicg_conversation_end_message, $wpaicg_human_name.': ') !== false){
                            $wpaicg_chatgpt_message = str_replace($wpaicg_human_name.': ','',$wpaicg_chatgpt_message);
                            $wpaicg_chatgpt_message = str_replace("\nAI: ",'',$wpaicg_chatgpt_message);
                            if(!empty($wpaicg_chatgpt_message)) {
                                $wpaicg_chatgpt_messages[] = array('role' => 'user', 'content' => $wpaicg_chatgpt_message);
                            }
                        }
                        else{
                            if(!empty($wpaicg_chatgpt_message)) {
                                $wpaicg_chatgpt_messages[] = array('role' => 'assistant', 'content' => $wpaicg_chatgpt_message);
                            }
                        }
                        $wpaicg_chat_greeting_message .= "\n" . $wpaicg_conversation_end_message;
                    }
                    $prompt = $wpaicg_chat_greeting_message;
                    //die;
                    /////////////////////
                    $wpaicg_data_request = [
                        'model' => 'gpt-3.5-turbo',
                        'messages' => $wpaicg_chatgpt_messages,
                        'temperature' => floatval(1),
                        'max_tokens' => intval(64),
                        'frequency_penalty' => floatval(0.01),
                        'presence_penalty' => floatval(0.01),
                        'top_p' => floatval(0.01)
                    ];
                    /*$wpaicg_data_request = [
                        'model' => 'text-embedding-ada-002',
                        'prompt' => $prompt,
                    ];
                    //print_r($wpaicg_data_request);
                    //die;
                    ////////////////////
                    //print_r($wpaicg_data_request);
                    $data = $openAiObj->complete($wpaicg_data_request);
                    print_r($data);
                    die;*/
                    $openAiObj->chat($wpaicg_data_request);
                    print_r($d);
                    die;
                } else {
                    echo $matchInfo['data'];
                }
                //print_r($matchInfo);
                echo "hello";
                die;

                echo "xxx";
                die;
                $this->helperData->embeddingRecordSave([
                    "content" => $this->jsonHelper->jsonEncode($productDataArr),
                    "token" => $result["usage"]['total_tokens'],
                    "type" => "products",
                    "estimated" => ($result["usage"]['total_tokens'] / 1000) * 0.0004
                ]);

                //die;
                /*$c_file = curl_file_create(__DIR__ . '/trandata.jsonl');
                $result = $openAiObj->uploadFile([
                            "purpose" => "fine-tune",
                            "file" => $c_file,
                ]);
                $resultD = $this->jsonHelper->jsonDecode($result, true);
                $result = $openAiObj->createFineTune([
                            "training_file" => $resultD["id"],
                            "model" => "ada"
                ]);*/
                /*print_r($result);
                echo "------------------";
                die;*/
                /*$search = $openAiObj->search([
                    'engine' => 'ada',
                    'documents' => ['White House', 'hospital', 'school'],
                    'query' => 'the president',
                ]);*/
                //$files = $openAiObj->listFiles();
                //print_r($files);
                //die;
            //    die;
                $result['msg'] = __('Products data exported for ChatGpt bot successfully.');
            } else {
                $result['msg'] = __('Please fill the all ChatGpt bot details in configuration and save the configuration.');
            }
            return $resultJson->setData($result);
        } catch (\Exception $e) {
            $this->logger->addError('product import : '.$e->getMessage());
            $result['msg'] = $e->getMessage();
            return $resultJson->setData($result);
        }
    }
}
