<?php
/**
 * @category   Webkul
 * @package    Webkul_ChatGptBot
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace Webkul\ChatGptBot\Controller\Adminhtml\Product;

use Magento\Framework\Controller\ResultFactory;
use Magento\Backend\App\Action\Context;
use Magento\Ui\Component\MassAction\Filter;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory;
use Webkul\ChatGptBot\Helper\Data as HelperData;

class MassExport extends \Magento\Backend\App\Action
{
    /**
     * Massactions filter.
     *
     * @var Filter
     */
    protected $filter;

    /**
     * @var CollectionFactory
     */
    protected $collectionFactory;

    /**
     * @param Context $context,
     * @param Filter $filter,
     * @param CollectionFactory $collectionFactory,
     * @param ScopeConfigInterface $scopeConfig,
     * @param ProductmapFactory $productMapRecord,
     * @param EbaycategorymapFactory $mapCategoryFactory
     */
    public function __construct(
        Context $context,
        Filter $filter,
        CollectionFactory $collectionFactory,
        HelperData $helperData
    ) {
        $this->filter = $filter;
        $this->collectionFactory = $collectionFactory;
        $this->helperData = $helperData;
        parent::__construct($context);
    }

    /**
     * @return \Magento\Backend\Model\View\Result\Redirect
     */
    public function execute()
    {
        try {
            $collection = $this->filter->getCollection($this->collectionFactory->create());
            $collection->addAttributeToSelect('*');
            $openAiObj = $this->helperData->getOpenAI();
            $pineconeClient = $this->helperData->getPineconeClient();
            $recordExported = 0;
            foreach ($collection as $product) {
                $productDataArr = $this->helperData->getProductDataForBot($product);
                $vectorData = $this->helperData->getEmbeddingsVartexData($openAiObj, $productDataArr);
                if ($vectorData) {
                    $proCategories = $productDataArr['Category'];
                    $pineconeClient->upsert(
                        $vectorData["data"][0]['embedding'],
                        "products",
                        $product->getEntityId(),
                        $proCategories
                    );

                    $this->helperData->embeddingRecordSave([
                        "content" => $this->helperData->getJsonHelper()->jsonEncode($productDataArr),
                        "token" => $vectorData["usage"]['total_tokens'],
                        "type" => "products",
                        "item_id" => $product->getEntityId(),
                        "estimated" => ($vectorData["usage"]['total_tokens'] / 1000) * 0.0004
                    ]);
                    $recordExported++;
                }
            }
            $this->messageManager->addSuccess(__('A total of %1 record(s) have been exported for ChatGPT bot.', $recordExported));
            return $this->resultFactory->create(ResultFactory::TYPE_REDIRECT)->setPath('catalog/product/index');
        } catch (\Exception $e) {
            $this->messageManager->addError($e->getMessage());
            $this->_redirect('catalog/product/index');
        }
    }

    /**
     * Check Order Map recode delete Permission.
     *
     * @return bool
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Webkul_ChatGptBot::product_add_gpt');
    }
}
