<?php
/**
 * Webkul Software.
 *
 * @category Webkul
 * @package Webkul_ChatGptBot
 * @author Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license https://store.webkul.com/license.html
 */


namespace Webkul\ChatGptBot\Model\ResourceModel;

/**
 * EmbeddingData Class
 */
class EmbeddingData extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    public function _construct()
    {
        $this->_init("wk_chatgptbot_embedding_data", "entity_id");
    }
}

