<?php
/**
 * Webkul Software.
 *
 * @category Webkul
 * @package Webkul_ChatGptBot
 * @author Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license https://store.webkul.com/license.html
 */


namespace Webkul\ChatGptBot\Model;

/**
 * EmbeddingDataRepository Class
 */
class EmbeddingDataRepository implements \Webkul\ChatGptBot\Api\EmbeddingDataRepositoryInterface
{
    protected $modelFactory = null;

    protected $collectionFactory = null;

    /**
     * initialize
     *
     * @param Webkul\ChatGptBot\Model\EmbeddingDataFactory $modelFactory
     * @param Webkul\ChatGptBot\Model\ResourceModel\EmbeddingData\CollectionFactory
     * $collectionFactory
     * @return void
     */
    public function __construct(\Webkul\ChatGptBot\Model\EmbeddingDataFactory $modelFactory, \Webkul\ChatGptBot\Model\ResourceModel\EmbeddingData\CollectionFactory $collectionFactory)
    {
        $this->modelFactory = $modelFactory; 
        $this->collectionFactory = $collectionFactory;
    }

    /**
     * get by id
     *
     * @param int $id
     * @return Webkul\ChatGptBot\Model\EmbeddingData
     */
    public function getById($id)
    {
        $model = $this->modelFactory->create()->load($id);
        if (!$model->getId()) { 
         throw new \Magento\Framework\Exception\NoSuchEntityException(__('The CMS block with the "%1" ID doesn\'t exist.', $id)); 
         } 
        return $model;
    }

    /**
     * get by id
     *
     * @param int $id
     * @return Webkul\ChatGptBot\Model\EmbeddingData
     */
    public function save(\Webkul\ChatGptBot\Model\EmbeddingData $subject)
    {
        try { 
         $subject->save(); 
        } catch (\Exception $exception) { 
         throw new \Magento\Framework\Exception\CouldNotSaveException(__($exception->getMessage())); 
        } 
         return $subject;
    }

    /**
     * get list
     *
     * @param Magento\Framework\Api\SearchCriteriaInterface $creteria
     * @return Magento\Framework\Api\SearchResults
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $creteria)
    {
        $collection = $this->collectionFactory->create(); 
         return $collection;
    }

    /**
     * delete
     *
     * @param Webkul\ChatGptBot\Model\EmbeddingData $subject
     * @return boolean
     */
    public function delete(\Webkul\ChatGptBot\Model\EmbeddingData $subject)
    {
        try { 
        $subject->delete();
        } catch (\Exception $exception) {
        throw new \Magento\Framework\Exception\CouldNotDeleteException(__($exception->getMessage()));
        }
        return true;
    }

    /**
     * delete by id
     *
     * @param int $id
     * @return boolean
     */
    public function deleteById($id)
    {
        return $this->delete($this->getById($id));
    }
}

