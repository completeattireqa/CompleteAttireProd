<?php
/**
 * Webkul Software.
 *
 * @category Webkul
 * @package Webkul_ChatGptBot
 * @author Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license https://store.webkul.com/license.html
 */


namespace Webkul\ChatGptBot\Model;

/**
 * EmbeddingData Class
 */
class EmbeddingData extends \Magento\Framework\Model\AbstractModel implements \Magento\Framework\DataObject\IdentityInterface, \Webkul\ChatGptBot\Api\Data\EmbeddingDataInterface
{
    final public const NOROUTE_ENTITY_ID = 'no-route';

    final public const CACHE_TAG = 'webkul_chatgptbot_embeddingdata';

    protected $_cacheTag = 'webkul_chatgptbot_embeddingdata';

    protected $_eventPrefix = 'webkul_chatgptbot_embeddingdata';

    /**
     * set resource model
     */
    public function _construct()
    {
        $this->_init(\Webkul\ChatGptBot\Model\ResourceModel\EmbeddingData::class);
    }

    /**
     * Load No-Route Indexer.
     *
     * @return $this
     */
    public function noRouteReasons()
    {
        return $this->load(self::NOROUTE_ENTITY_ID, $this->getIdFieldName());
    }

    /**
     * Get identities.
     *
     * @return []
     */
    public function getIdentities()
    {
        return [self::CACHE_TAG.'_'.$this->getId()];
    }

    /**
     * Set EntityId
     *
     * @param int $entityId
     * @return Webkul\ChatGptBot\Model\EmbeddingDataInterface
     */
    public function setEntityId($entityId)
    {
        return $this->setData(self::ENTITY_ID, $entityId);
    }

    /**
     * Get EntityId
     *
     * @return int
     */
    public function getEntityId()
    {
        return parent::getData(self::ENTITY_ID);
    }

    /**
     * Set StoreId
     *
     * @param int $storeId
     * @return Webkul\ChatGptBot\Model\EmbeddingDataInterface
     */
    public function setStoreId($storeId)
    {
        return $this->setData(self::STORE_ID, $storeId);
    }

    /**
     * Get StoreId
     *
     * @return int
     */
    public function getStoreId()
    {
        return parent::getData(self::STORE_ID);
    }

    /**
     * Set Content
     *
     * @param string $content
     * @return Webkul\ChatGptBot\Model\EmbeddingDataInterface
     */
    public function setContent($content)
    {
        return $this->setData(self::CONTENT, $content);
    }

    /**
     * Get Content
     *
     * @return string
     */
    public function getContent()
    {
        return parent::getData(self::CONTENT);
    }

    /**
     * Set Token
     *
     * @param int $token
     * @return Webkul\ChatGptBot\Model\EmbeddingDataInterface
     */
    public function setToken($token)
    {
        return $this->setData(self::TOKEN, $token);
    }

    /**
     * Get Token
     *
     * @return int
     */
    public function getToken()
    {
        return parent::getData(self::TOKEN);
    }

    /**
     * Set Type
     *
     * @param string $type
     * @return Webkul\ChatGptBot\Model\EmbeddingDataInterface
     */
    public function setType($type)
    {
        return $this->setData(self::TYPE, $type);
    }

    /**
     * Get Type
     *
     * @return string
     */
    public function getType()
    {
        return parent::getData(self::TYPE);
    }

    /**
     * Set Estimated
     *
     * @param float $estimated
     * @return Webkul\ChatGptBot\Model\EmbeddingDataInterface
     */
    public function setEstimated($estimated)
    {
        return $this->setData(self::ESTIMATED, $estimated);
    }

    /**
     * Get Estimated
     *
     * @return float
     */
    public function getEstimated()
    {
        return parent::getData(self::ESTIMATED);
    }

    /**
     * Set CreatedAt
     *
     * @param string $createdAt
     * @return Webkul\ChatGptBot\Model\EmbeddingDataInterface
     */
    public function setCreatedAt($createdAt)
    {
        return $this->setData(self::CREATED_AT, $createdAt);
    }

    /**
     * Get CreatedAt
     *
     * @return string
     */
    public function getCreatedAt()
    {
        return parent::getData(self::CREATED_AT);
    }
}

