#Installation

Magento2 Webkul ChatGPT Bot module installation is very easy, please follow the steps for installation-

1. Unzip the respective extension zip and create Webkul(vendor) and ChatGptBot(module) name folder inside your magento/app/code/ directory and then move all module's files into magento root directory Magento2/app/code/Webkul/ChatGptBot/ folder.

Run Following Command via terminal
-----------------------------------

php bin/magento setup:upgrade
php bin/magento setup:di:compile
php bin/magento setup:static-content:deploy

2. Flush the cache and reindex all.

now module is properly installed

#User Guide

For Magento2 Webkul ChatGPT Bot module's working process follow user guide - http://webkul.com/blog/

#Support

Find us our support policy - https://store.webkul.com/support.html/

#Refund

Find us our refund policy - https://store.webkul.com/refund-policy.html/

----------------------------------------------------------------------------------------
Note - This readme file is strictly need to use when you have purchased the software from
webkul store i.e https://store.webkul.com . If you purchase the module from magento marketplace
connect this readme file will not work.
