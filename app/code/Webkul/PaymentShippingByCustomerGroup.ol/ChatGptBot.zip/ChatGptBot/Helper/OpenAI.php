<?php
/**
 * @category   Webkul
 * @package    Webkul_ChatGptBot
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace Webkul\ChatGptBot\Helper;

class OpenAI{
    public const YOUR_FINE_TUNED_MODEL_NAME = 'ada';
    //protected $secretKey = "";
    //protected $baseURL = "";
    //protected $defaultEngine = "";
    function __construct(
        public $secretKey,
        public $baseURL = "https://api.openai.com/v1/",
        private $defaultEngine = "davinci" // ada, babbage, etc
    ) {
        $this->secretKey = $secretKey;
        $this->baseURL = $baseURL;
        $this->defaultEngine = $defaultEngine;
    }

    public function setDefaultEngine(string $defaultEngine): void{
        $this->defaultEngine = $defaultEngine;
    }

    /**
     * @param string $url
     * @param string $type
     * @param string $postFields
     * @return array
     */
    public function _curl(string $url, string $type = "POST", string $postFields = "")
    {
        $url = $this->baseURL . $url;
        $curl = curl_init();
        $curlOpts = [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 200,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Authorization: Bearer '.$this->secretKey
            ],
        ];
        if($type == "POST"){
            $curlOpts[CURLOPT_CUSTOMREQUEST] = "POST";
            $curlOpts[CURLOPT_POSTFIELDS] = $postFields;
        }
        curl_setopt_array($curl, $curlOpts);
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        return $err ? ["error" => "Error #:" . $err ] : json_decode($response, true);
    }

    /**
     * RemoveUnfinishedSentence
     *
     * @param string $str
     * @return string
     */
    private function _removeUnfinishedSentence(string $str)
    {
        //return preg_replace("/\.[^.]+$/", "", $str) ?? $str;
        return $str;
    }

    public function search(array $documents, $query): array|stdClass|string {

        $request_body = [
            "max_tokens" => 10,
            "temperature" => 0.7,
            "top_p" => 1,
            "presence_penalty" => 0.75,
            "frequency_penalty"=> 0.75,
            "documents" => $documents,
            "query" => $query
        ];

        $postFields = json_encode($request_body);


        return $this->_curl(url: "engines/" . $this->defaultEngine . "/search", postFields: $postFields );
    }

    /**
     * Complete
     *
     * @param array $parameters
     * @return array|stdClass|string
     */
    public function complete($parameters)
    {
        $requestBody = [
            "max_tokens" => 100,
            "top_p" => 1,
            "best_of"=> 1,
            "stream" => false,
            "stop" => ["\n"],
            "top_p" => 1
            //"temperature" => 0.7,          //These 3 commented because they are sent by the calling function
            //"presence_penalty" => 0.75,
            //"frequency_penalty"=> 0.75,
        ];

        if (!empty($parameters)) {
            $requestBody = array_merge($requestBody, $parameters);
        }

        $postFields = json_encode($requestBody);
        if (isset($requestBody["model"])) {
            $result = $this->_curl(url: "completions", postFields: $postFields );
        } else {
            $result = $this->_curl(url: "engines/" . $this->defaultEngine . "/completions", postFields: $postFields );
        }
        print_r($result);
        die;
        return $this->_removeUnfinishedSentence(($result['choices'][0]['text'] ?? json_encode($result)));
        //return $returnResult ? ($json ? json_encode($result) : $result) : $this->_removeUnfinishedSentence($prompt . ($result?->choices[0]?->text ?? ""));
    }

    /**
     * Chat
     *
     * @param array $parameters
     * @return array|stdClass|string
     */
    public function chat($parameters)
    {
        $postFields = json_encode($parameters);
        if (isset($parameters["model"])) {
            $result = $this->_curl(url: "chat/completions", postFields: $postFields );
        } else {
            $result = $this->_curl(url: "engines/" . $this->defaultEngine . "/chat/completions", postFields: $postFields );
        }
        return $this->_removeUnfinishedSentence(($result['choices'][0]['message']['content'] ?? ""));
        //return $returnResult ? ($json ? json_encode($result) : $result) : $this->_removeUnfinishedSentence($prompt . ($result?->choices[0]?->text ?? ""));
    }

    /**
     * Embeddings
     *
     * @param string $embeddingsData
     */
    public function embeddings($embeddingsData)
    {
        $postFields = json_encode($embeddingsData);
        return $result = $this->_curl(url: "embeddings", postFields: $postFields);

    }
}
