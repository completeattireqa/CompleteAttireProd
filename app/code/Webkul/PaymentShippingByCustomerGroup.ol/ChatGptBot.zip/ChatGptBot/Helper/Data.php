<?php
/**
 * ChatGptBot helper data
 * @category  Webkul
 * @package   Webkul_ChatGptBot
 * @author    Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */

namespace Webkul\ChatGptBot\Helper;

use Magento\Framework\Stdlib\DateTime\TimezoneInterface;
use Magento\Framework\Encryption\EncryptorInterface;
use Magento\Framework\Data\Form\FormKey;
use Magento\Store\Model\StoreManagerInterface;
use Magento\Framework\Json\Helper\Data as JsonHelper;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Model\ResourceModel\Category\CollectionFactory;
use Webkul\ChatGptBot\Model\EmbeddingDataFactory;
use Webkul\ChatGptBot\Helper\Pinecone;
use Webkul\ChatGptBot\Helper\OpenAI;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    private $storeManager;

    /**
     * @var \Magento\Framework\HTTP\Client\Curl
     */
    private $curl;

    /**
     * @var \Magento\Framework\Data\Form\FormKey
     */
    private $formkey;

    /**
     * @var \Webkul\Modulename\Logger\Logger
     */
    private $logger;

    /**
     * @var \Magento\Framework\Stdlib\DateTime\TimezoneInterface
     */
    private $dateTime;

    /**
     * @var \Magento\Framework\Encryption\EncryptorInterface
     */
    private $encryptor;

    /**
     * @var \Magento\Framework\Json\Helper\Data
     */
    private $jsonHelper;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Framework\HTTP\Client\Curl $curl
     * @param StoreManagerInterface $storeManager
     * @param FormKey $formkey
     * @param TimezoneInterface $dateTime
     * @param EncryptorInterface $encryptor
     * @param JsonHelper $jsonHelper
     * @param \Webkul\ChatGptBot\Logger\Logger $logger
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\HTTP\Client\Curl $curl,
        \Magento\Framework\Escaper $escaper,
        ProductRepositoryInterface $productRepository,
        CollectionFactory $categoryCollectionFactory,
        StoreManagerInterface $storeManager,
        FormKey $formkey,
        TimezoneInterface $dateTime,
        EncryptorInterface $encryptor,
        JsonHelper $jsonHelper,
        EmbeddingDataFactory $embeddingData,
        \Webkul\ChatGptBot\Logger\Logger $logger
    ) {
        $this->curl = $curl;
        $this->escaper = $escaper;
        $this->productRepository = $productRepository;
        $this->categoryCollectionFactory = $categoryCollectionFactory->create()
                ->addAttributeToSelect('*')->addIsActiveFilter();
        $this->storeManager = $storeManager;
        $this->formkey = $formkey;
        $this->dateTime = $dateTime;
        $this->encryptor = $encryptor;
        $this->jsonHelper = $jsonHelper;
        $this->embeddingData = $embeddingData;
        $this->logger = $logger;
        parent::__construct($context);
    }

    /**
     * Get Logger
     *
     * @return \Webkul\ChatGptBot\Logger\Logger
     */
    public function getLogger()
    {
        return $this->logger;
    }

    /**
     * Get JsonHelper
     *
     * @return \Magento\Framework\Json\Helper\Data
     */
    public function getJsonHelper()
    {
        return $this->jsonHelper;
    }

    /**
     * Get DateTime
     *
     * @return \Magento\Framework\Stdlib\DateTime\TimezoneInterface
     */
    public function getDateTime()
    {
        return $this->dateTime;
    }

    /**
     * Get StoreManager
     *
     * @return \Magento\Store\Model\StoreManagerInterface
     */
    public function getStoreManager()
    {
        return $this->storeManager;
    }

    /**
     * Get Configuration Detail.
     *
     * @return array of Configuration Detail
     */
    public function getConfiguration()
    {
        $path = 'chatgptbot/general_settings/';
        $pineconePath = 'chatgptbot/pinecone/';
        $eBayConfig = [
            'enable' => $this->scopeConfig->getValue($path.'enable'),
            'secret_key' => $this->encryptor->decrypt($this->scopeConfig->getValue($path.'secret_key')),
            'pinecone_index' => $this->scopeConfig->getValue($pineconePath.'index'),
            'pinecone_key' => $this->encryptor->decrypt($this->scopeConfig->getValue($pineconePath.'secret_key'))
        ];
        return $eBayConfig;
    }

    /**
     * Get StoreConfigValue
     *
     * @param string $path
     * @return string
     */
    public function getStoreConfigValue($path)
    {
        return $this->scopeConfig->getValue($path);
    }

    /**
     * Get OpenAI client
     *
     * @return \Webkul\ChatGptBot\Helper\OpenAI
     */
    public function getOpenAI()
    {
        $client = false;
        $config = $this->getConfiguration();
        if ($config['enable']) {
            $client = new OpenAI($config['secret_key']);
        }
        return $client;
    }

    /**
     * Get Pinecone client
     *
     * @return \Webkul\ChatGptBot\Helper\Pinecone
     */
    public function getPineconeClient()
    {
        $client = false;
        $config = $this->getConfiguration();
        if ($config['enable']) {
            $client = new Pinecone($config['pinecone_key'], $config['pinecone_index']);
        }
        return $client;
    }

    /**
     * EmbeddingRecordSave
     *
     * @param $data
     * @return void
     */
    public function embeddingRecordSave($data)
    {
        $recordData = $this->embeddingData->create()->getCollection()
                            ->addFieldToFilter("type", ["eq" => $data["type"]])
                            ->addFieldToFilter("item_id", ["eq" => $data["item_id"]])
                            ->setPageSize(1)->setCurPage(1)->getFirstItem();
        if ($recordData->getEntityId()) {
            $recordData->setContent($data['content'])->save();
        } else {
            $embeddingData = $this->embeddingData->create();
            $embeddingData->setData($data)->save();
        }
    }

    /**
     * GetData according to
     */
     public function getDataAsVertex($vertexData)
     {
         $productData = "";
         switch ($vertexData[0]) {
             case 'products':
                $product = $this->productRepository->getById($vertexData[1]);
                $productData = $this->getProductDataForBot($product);
                break;
              default:
               $product = $this->productRepository->getById($vertexData[0]);
               $productData = $this->getProductDataForBot($product);
               break;
         }
         return $productData;
     }

     /**
      * GetProductDataForBot
      *
      * @param Magento\Catalog\Model\Product $product
      * @return array
      */
     public function getProductDataForBot($product)
     {
         
         $tempCatColl = $this->categoryCollectionFactory;
         $categoryList = $tempCatColl->addAttributeToFilter('entity_id', $product->getCategoryIds())->getColumnValues('name');
         $productDataArr = [
             "Entity Id" => $product->getEntityId(),
             "Sku" => $this->escaper->escapeHtml($product->getSku()),
             "Status" => 1,
             "Name" => $this->escaper->escapeHtml($product->getName()),
             "Meta Title" => $this->escaper->escapeHtml($product->getMetaTitle()),
             "Meta Description" => $this->escaper->escapeHtml($product->getMetaDescription()),
             "Description" => $this->escaper->escapeHtml($product->getDescription()),
             "Short Description" => $this->escaper->escapeHtml($product->getShortDescription()),
             "Meta Keyword" => $this->escaper->escapeHtml($product->getMetaKeyword()),
             "Price" => $product->getPrice(),
             "Weight" => $product->getWeight(),
             "Tax Class" => $this->escaper->escapeHtml($product->getAttributeText('tax_class_id')),
             "Condition" => $this->escaper->escapeHtml($product->getAttributeText('condition')),
            // "Ab01" => $this->escaper->escapeHtml($product->getAttributeText('ab01')),
             //"Services" => $product->getAttributeText('services'),
             //"Store Id" => $product->getAttributeText('store_id'),
             "Url" => $product->getProductUrl(),
             "Category" => $this->escaper->escapeHtml(implode(", ", $categoryList))
         ];
         return $productDataArr;
     }

     /**
      * GetEmbeddingsVartexData
      *
      * @param OpenAI $openAiObj
      * @param array $productDataArr
      */
     public function getEmbeddingsVartexData($openAiObj, $productDataArr)
     {
         $result = $openAiObj->embeddings([
             "model" => "text-embedding-ada-002",
             "input" => $this->jsonHelper->jsonEncode([$this->jsonHelper->jsonEncode($productDataArr)])
         ]);
         return isset($result["data"][0]['embedding']) ? $result : false;
     }
}
