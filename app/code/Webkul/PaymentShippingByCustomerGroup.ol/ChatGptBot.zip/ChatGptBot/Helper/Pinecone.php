<?php
/**
 * @category   Webkul
 * @package    Webkul_ChatGptBot
 * @author     Webkul Software Private Limited
 * @copyright  Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license    https://store.webkul.com/license.html
 */
namespace Webkul\ChatGptBot\Helper;

class Pinecone{
    //protected $secretKey = "";
    //protected $baseURL = "";
    //protected $defaultEngine = "";
    function __construct(
        public $secretKey,
        public $vectorDbIndex,
    ) {
        $this->secretKey = $secretKey;
        $this->baseURL = "https://".$vectorDbIndex."/";
    }

    /**
     * @param string $url
     * @param string $type
     * @param string $postFields
     * @return array
     */
    public function _curl(string $url, string $type = "POST", string $postFields = "")
    {
        $url = $this->baseURL . $url;
        $curl = curl_init();
        $curlOpts = [
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_ENCODING => "",
            CURLOPT_MAXREDIRS => 10,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
            CURLOPT_HTTPHEADER => [
                'Content-Type: application/json',
                'Api-Key:'.$this->secretKey
            ],
        ];
        if($type == "POST"){
            $curlOpts[CURLOPT_CUSTOMREQUEST] = "POST";
            $curlOpts[CURLOPT_POSTFIELDS] = $postFields;
        }
        curl_setopt_array($curl, $curlOpts);
        $response = curl_exec($curl);
        $err = curl_error($curl);
        curl_close($curl);
        return $err ? ["error" => "Error #:" . $err ] : json_decode($response, true);
    }

    /**
     * Upsert
     *
     * @param array $vectorsData
     * @param string $index
     * @param string $proCategories
     */
    public function upsert($vectorsData, $index, $productId, $proCategories = "")
    {
        $requestBody = [
            "vectors" => [
                [
                    "id" => $index."-".$productId,
                    "metadata" => [
                        "category" => $proCategories
                    ],
                    "values" => $vectorsData
                ]
            ],
            //"namespace" => $index
        ];

        $postFields = json_encode($requestBody);
        $result = $this->_curl(url: "vectors/upsert", postFields: $postFields);
        return $result['upsertedCount'] ?? false;
    }

    /**
     * Query
     *
     * @param array $queryVectorsData
     */
    public function query($queryVectorsData)
    {
        $requestBody = [
            "vector" => $queryVectorsData,
            "topK" => 1
        ];
        $postFields = json_encode($requestBody);
        $body = $this->_curl(url: "query", postFields: $postFields);
        $result = [];
        if ($body) {
            if (isset($body['matches']) && is_array($body['matches']) && count($body['matches'])) {
                /*$data = '';
                foreach($body['matches'] as $match){
                    $wpaicg_embedding = $match['id'];
                    if ($wpaicg_embedding) {
                        $data .= empty($data) ? $wpaicg_embedding->post_content : "\n".$wpaicg_embedding->post_content;
                    }

                }*/
                $result['data'] = $body['matches'];
                $result['status'] = 'success';
            }
        } else {
            $result['data'] = 'Pinecone return empty';
        }
        return $result;
    }
}
