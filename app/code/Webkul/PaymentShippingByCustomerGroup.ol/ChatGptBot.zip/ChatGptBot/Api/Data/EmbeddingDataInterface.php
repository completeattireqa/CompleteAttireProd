<?php
/**
 * Webkul Software.
 *
 * @category Webkul
 * @package Webkul_ChatGptBot
 * @author Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license https://store.webkul.com/license.html
 */


namespace Webkul\ChatGptBot\Api\Data;

/**
 * EmbeddingData Interface
 */
interface EmbeddingDataInterface
{
    public const ENTITY_ID = 'entity_id';

    public const STORE_ID = 'store_id';

    public const CONTENT = 'content';

    public const TOKEN = 'token';

    public const TYPE = 'type';

    public const ESTIMATED = 'estimated';

    public const CREATED_AT = 'created_at';

    /**
     * Set EntityId
     *
     * @param int $entityId
     * @return Webkul\ChatGptBot\Api\Data\EmbeddingDataInterface
     */
    public function setEntityId($entityId);
    /**
     * Get EntityId
     *
     * @return int
     */
    public function getEntityId();
    /**
     * Set StoreId
     *
     * @param int $storeId
     * @return Webkul\ChatGptBot\Api\Data\EmbeddingDataInterface
     */
    public function setStoreId($storeId);
    /**
     * Get StoreId
     *
     * @return int
     */
    public function getStoreId();
    /**
     * Set Content
     *
     * @param string $content
     * @return Webkul\ChatGptBot\Api\Data\EmbeddingDataInterface
     */
    public function setContent($content);
    /**
     * Get Content
     *
     * @return string
     */
    public function getContent();
    /**
     * Set Token
     *
     * @param int $token
     * @return Webkul\ChatGptBot\Api\Data\EmbeddingDataInterface
     */
    public function setToken($token);
    /**
     * Get Token
     *
     * @return int
     */
    public function getToken();
    /**
     * Set Type
     *
     * @param string $type
     * @return Webkul\ChatGptBot\Api\Data\EmbeddingDataInterface
     */
    public function setType($type);
    /**
     * Get Type
     *
     * @return string
     */
    public function getType();
    /**
     * Set Estimated
     *
     * @param float $estimated
     * @return Webkul\ChatGptBot\Api\Data\EmbeddingDataInterface
     */
    public function setEstimated($estimated);
    /**
     * Get Estimated
     *
     * @return float
     */
    public function getEstimated();
    /**
     * Set CreatedAt
     *
     * @param string $createdAt
     * @return Webkul\ChatGptBot\Api\Data\EmbeddingDataInterface
     */
    public function setCreatedAt($createdAt);
    /**
     * Get CreatedAt
     *
     * @return string
     */
    public function getCreatedAt();
}

