<?php
/**
 * Webkul Software.
 *
 * @category Webkul
 * @package Webkul_ChatGptBot
 * @author Webkul
 * @copyright Copyright (c) Webkul Software Private Limited (https://webkul.com)
 * @license https://store.webkul.com/license.html
 */


namespace Webkul\ChatGptBot\Api;

/**
 * EmbeddingDataRepository Interface
 */
interface EmbeddingDataRepositoryInterface
{
    /**
     * Get by id
     *
     * @param int $id
     * @return Webkul\ChatGptBot\Model\EmbeddingData
     */
    public function getById($id);
    /**
     * Save
     *
     * @param int $id
     * @return Webkul\ChatGptBot\Model\EmbeddingData
     */
    public function save(\Webkul\ChatGptBot\Model\EmbeddingData $subject);
    /**
     * Get list
     *
     * @param Magento\Framework\Api\SearchCriteriaInterface $creteria
     * @return Magento\Framework\Api\SearchResults
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $creteria);
    /**
     * Delete
     *
     * @param Webkul\ChatGptBot\Model\EmbeddingData $subject
     * @return boolean
     */
    public function delete(\Webkul\ChatGptBot\Model\EmbeddingData $subject);
    /**
     * Delete by id
     *
     * @param int $id
     * @return boolean
     */
    public function deleteById($id);
}

