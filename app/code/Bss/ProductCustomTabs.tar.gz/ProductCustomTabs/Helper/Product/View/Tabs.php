<?php
/**
 * BSS Commerce Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://bsscommerce.com/Bss-Commerce-License.txt
 *
 * @category   BSS
 * @package    BSS_ProductCustomTabs
 * @author     Extension Team
 * @copyright  Copyright (c) 2017-2018 BSS Commerce Co. ( http://bsscommerce.com )
 * @license    http://bsscommerce.com/Bss-Commerce-License.txt
 */
namespace Bss\ProductCustomTabs\Helper\Product\View;

use \Bss\ProductCustomTabs\Model;
use Magento\Cms\Model\Template\FilterProvider;
use Magento\Framework\Api\FilterBuilder;
use Magento\Catalog\Model\ResourceModel\Eav\AttributeFactory;
use \Magento\Catalog\Model\ProductRepositoryFactory;
use Magento\Framework\Pricing\PriceCurrencyInterface;
use Magento\Framework\Phrase;

class Tabs extends \Magento\Framework\App\Helper\AbstractHelper
{

    /**
     * Resource Tab
     *
     * @var Model\ResourceModel\Tab $resourceTab
     */
    protected $resourceTab;

    /**
     * Http
     *
     * @var \Magento\Framework\App\Request\Http $request
     */
    protected $request;

    /**
     * Collection Factory
     *
     * @var Model\ResourceModel\Tab\CollectionFactory $tabCollectionFactory
     */
    protected $tabCollectionFactory;

    /**
     * Rule Factory
     *
     * @var RuleFactory $ruleFactory
     */
    protected $ruleFactory;

    /**
     * Tab Factory
     *
     * @var Model\TabFactory $tabFactory
     */
    protected $tabFactory;

    /**
     * Filter Provider
     *
     * @var FilterProvider $filterProvider
     */
    protected $filterProvider;

    /**
     * Filter Builder
     *
     * @var FilterBuilder $filterBuilder
     */
    protected $filterBuilder;

    /**
     * Store Manager Interface
     *
     * @var \Magento\Store\Model\StoreManagerInterface $storeManager
     */
    protected $storeManager;

    /**
     * Session Factory
     *
     * @var \Magento\Customer\Model\SessionFactory $customerSession
     */
    protected $customerSession;

    /**
     * Registry
     *
     * @var \Magento\Framework\Registry $registry
     */
    protected $registry;

    /**
     * Order Factory
     *
     * @var \Magento\Sales\Model\OrderFactory $orderFactory
     */
    protected $orderFactory;

    /**
     * Order Items Factory
     *
     * @var \Magento\Sales\Model\Order\ItemFactory $orderItemsFactory
     */
    protected $orderItemsFactory;

    /**
     * Attribute Factory
     *
     * @var AttributeFactory $attributeFactory
     */
    protected $attributeFactory;

    /**
     * Product Repository Factory
     *
     * @var ProductRepositoryFactory $productRepositoryFactory
     */
    protected $productRepositoryFactory;

    /**
     * Helper Output
     *
     * @var \Magento\Catalog\Helper\Output $helperOutput
     */
    protected $helperOutput;

    /**
     * Price Currency Interface
     *
     * @var PriceCurrencyInterface $priceCurrency
     */
    protected $priceCurrency;

    /**
     * ConfigAdmin
     *
     * @var \Bss\ProductCustomTabs\Helper\Config\ConfigAdmin $helperConfigAdmin
     */
    protected $helperConfigAdmin;

    /**
     * Tab Product Collection Factory
     *
     * @var Model\ResourceModel\Product\CollectionFactory $productTabCollection
     */
    protected $productTabCollection;

    /**
     * Tabs constructor.
     *
     * @param Model\ResourceModel\Product\CollectionFactory $productTabCollection
     * @param AttributeFactory $attributeFactory
     * @param Model\ResourceModel\Tab $resourceTab
     * @param Model\ResourceModel\Tab\CollectionFactory $tabCollectionFactory
     * @param Model\RuleFactory $ruleFactory
     * @param Model\TabFactory $tabFactory
     * @param \Magento\Framework\App\Request\Http $request
     * @param \Magento\Framework\App\Helper\Context $context
     * @param FilterProvider $filterProvider
     * @param FilterBuilder $filterBuilder
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Customer\Model\SessionFactory $customerSession
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Sales\Model\OrderFactory $orderFactory
     * @param \Magento\Sales\Model\Order\ItemFactory $orderItemsFactory
     * @param ProductRepositoryFactory $productRepositoryFactory
     * @param \Magento\Catalog\Helper\Output $helperOutput
     * @param PriceCurrencyInterface $priceCurrency
     * @param \Bss\ProductCustomTabs\Helper\Config\ConfigAdmin $helperConfigAdmin
     */
    public function __construct(
        Model\ResourceModel\Product\CollectionFactory $productTabCollection,
        AttributeFactory $attributeFactory,
        Model\ResourceModel\Tab $resourceTab,
        Model\ResourceModel\Tab\CollectionFactory $tabCollectionFactory,
        Model\RuleFactory $ruleFactory,
        Model\TabFactory $tabFactory,
        \Magento\Framework\App\Request\Http $request,
        \Magento\Framework\App\Helper\Context $context,
        FilterProvider $filterProvider,
        FilterBuilder $filterBuilder,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Customer\Model\SessionFactory $customerSession,
        \Magento\Framework\Registry $registry,
        \Magento\Sales\Model\OrderFactory $orderFactory,
        \Magento\Sales\Model\Order\ItemFactory $orderItemsFactory,
        ProductRepositoryFactory $productRepositoryFactory,
        \Magento\Catalog\Helper\Output $helperOutput,
        PriceCurrencyInterface $priceCurrency,
        \Bss\ProductCustomTabs\Helper\Config\ConfigAdmin $helperConfigAdmin
    ) {
        $this->productTabCollection = $productTabCollection;
        $this->attributeFactory = $attributeFactory;
        $this->resourceTab = $resourceTab;
        $this->ruleFactory = $ruleFactory;
        $this->tabCollectionFactory = $tabCollectionFactory;
        $this->tabFactory = $tabFactory;
        $this->request = $request;
        $this->filterProvider = $filterProvider;
        $this->filterBuilder = $filterBuilder;
        $this->storeManager = $storeManager;
        $this->customerSession = $customerSession;
        $this->registry = $registry;
        $this->orderFactory = $orderFactory;
        $this->orderItemsFactory = $orderItemsFactory;
        $this->productRepositoryFactory = $productRepositoryFactory;
        $this->helperOutput = $helperOutput;
        $this->priceCurrency = $priceCurrency;
        $this->helperConfigAdmin = $helperConfigAdmin;
        parent::__construct($context);
    }

    /**
     * Remove Tabs Default
     *
     * @param array $detailedInfoGroup
     * @return void
     */
    public function removeTabsDefault(&$detailedInfoGroup = [])
    {
        if (is_array($detailedInfoGroup)) {
            for ($i = 0; $i <= 2; $i++) {
                unset($detailedInfoGroup[$i]);
            }
        }
    }

    /**
     * Get Config Admin
     *
     * @return \Bss\ProductCustomTabs\Helper\Config\ConfigAdmin
     */
    public function getConfigAdmin()
    {
        return $this->helperConfigAdmin;
    }

    /**
     * @return mixed
     */
    public function getConfigHideDefaultTabs()
    {
        return $this->getConfigAdmin()->getConfigHideDefaultTabs();
    }

    /**
     * Get Product Customer Purchased
     *
     * @return array
     */
    protected function getProductCustomerPurchased()
    {
        $productIds = [];
        if ($this->customerSession->create()->isLoggedIn()) {
            $customerId = $this->customerSession->create()->getId();

            $orderIds = $this->orderFactory->create()->getCollection()
            ->addFieldToFilter(
                "customer_id",
                $customerId
            )->getAllIds();
            $productIds = $this->orderItemsFactory->create()->getCollection()->addAttributeToSelect('product_id')
            ->addFieldToFilter(
                'order_id',
                [
                    'in' => $orderIds
                ]
            )->addFieldToFilter(
                'parent_item_id',
                [
                    'null' => true
                ]
            );
            $productIds = $productIds->getData();
        }

        return $productIds;
    }


    /**
     * Load Tab By Id
     *
     * @param int $tabId
     *
     * @return Model\Tab
     */
    protected function loadTabById($tabId)
    {
        return $this->tabFactory->create()->load($tabId);
    }

    /**
     * Get Tabs By Store View
     *
     * @return array
     *
     * @throws \Exception
     */
    public function getTabsByStoreView()
    {

        $storeId = $this->storeManager->getStore()->getId();
        $customerGroupId = $this->customerSession->create()->getCustomerGroupId();
        $currentProductId = $this->registry->registry('current_product')->getId();
        $arrTab = [];
        try {
            $collection = $this->productTabCollection->create(
            )->addFieldToFilter(
                'store_id',
                [
                    'eq' => $storeId
                ]
            )->addFieldToFilter(
                'product_id',
                ['eq' => $currentProductId]
            )->addFieldToFilter(
                'status',
                [
                    'eq' => 1
                ]
            );
            $collection->setOrder(
                'position',
                'ASC'
            );
            $arrData = $collection->getItems();
            $arrTabs = [];
            $stt = 0;
            $arrParentTabIds = [];
            foreach ($arrData as $tab) {
                $parentId = $tab->getData('parent_id');
                $this->getAllParentIdsByTab($parentId, $arrParentTabIds);
                $customerGroupIds = $this->resourceTab->getCustomerGroupIdsByTabId($tab->getId());
                $arrTabs[] = $tab->getData();
                $arrTabs[$stt]['group_customer_ids'] = $customerGroupIds;
                $stt++;
            }

            foreach ($arrTabs as $key => $tab) {
                if (in_array($tab['id'], $arrParentTabIds)) {
                    unset($arrTabs[$key]);
                }
            }
            $arrTab = [];
            $arrCurrentProductId = ['product_id' => $currentProductId];

            foreach ($arrTabs as $tab) {
                $customerGroupIds = $this->resourceTab->getCustomerGroupTable($tab['id']);
                $customerPurchasedIds = $this->getProductCustomerPurchased();

                if (in_array($customerGroupId, $customerGroupIds)) {
                    if ($tab['visible_customer_purchased'] &&
                        in_array($arrCurrentProductId, $customerPurchasedIds)
                    ) {
                        $arrTab[] = [
                            'tab_id' => $tab['id'],
                            'title' => $tab['title'],
                            'content' => $tab['content'],
                            'attribute_ids' => $tab['attribute_ids'],
                            'show_related_products' => $tab['show_related_products'],
                            'show_up_sell_products' => $tab['show_up_sell_products'],
                            'show_cross_sell_products' => $tab['show_cross_sell_products']
                        ];
                    } elseif (!$tab['visible_customer_purchased']) {
                        $arrTab[] = [
                            'tab_id' => $tab['id'],
                            'title' => $tab['title'],
                            'content' => $tab['content'],
                            'attribute_ids' => $tab['attribute_ids'],
                            'show_related_products' => $tab['show_related_products'],
                            'show_up_sell_products' => $tab['show_up_sell_products'],
                            'show_cross_sell_products' => $tab['show_cross_sell_products']
                        ];
                    }

                }
            }

        } catch (\Exception $exception) {
            $this->_logger->debug($exception->getMessage());
        }

        return $arrTab;
    }

    /**
     * Get All Parent Ids By Tab
     * @param int $parentId
     * @param array $arrParentTabIds
     */
    protected function getAllParentIdsByTab($parentId, &$arrParentTabIds)
    {
        while ($parentId != 0) {
            $tabId = $parentId;
            $parentId = $this->resourceTab->getParentIdByTab($tabId);
            $arrParentTabIds[] = $tabId;
        }
    }

    /**
     * Load Attribute
     *
     * @param int $attributeId
     * @return \Magento\Catalog\Model\ResourceModel\Eav\Attribute
     */
    protected function loadAtribute($attributeId)
    {
        return $this->attributeFactory->create()->load($attributeId);
    }

    /**
     * Get Attributes Content
     * @param string $attributeIdsOfTab
     * @return string
     */
    public function getAttributesContent($attributeIdsOfTab)
    {
        $content = '';
        $arrAttributes = explode('&', $attributeIdsOfTab);
        if (is_array($arrAttributes)) {
            foreach ($arrAttributes as $attributeId) {
                $modelAttribute = $this->loadAtribute($attributeId);

                $currentProduct = $this->registry->registry('product');
                $value = $modelAttribute->getFrontend()->getValue($currentProduct);

                if (!$currentProduct->hasData($modelAttribute->getAttributeCode())) {
                    $value = __('N/A');
                } elseif ($modelAttribute->getFrontendInput() == 'price' && is_string($value)) {
                    $value = $this->priceCurrency->convertAndFormat($value);
                }

                if ($value instanceof Phrase || (is_string($value) && $value != '')) {
                    $labelAttribute = $modelAttribute->getStoreLabel();
                    $valueContent = $this->helperOutput->productAttribute(
                        $currentProduct,
                        $value,
                        $modelAttribute->getAttributeCode()
                    );
                    if ($labelAttribute != '') {
                        $content .= "<tr>
                                <td style='font-weight: bold'>
                                    $labelAttribute
                                </td>
                                <td>
                                    $valueContent
                                </td>
                              <tr>";
                    }
                }
            }
        }

        return $content;
    }

    /**
     * Get Related Product Content
     *
     * @param int $relatedContent
     * @return string
     */
    public function getRelatedProductContent($relatedContent)
    {

        if ($relatedContent) {
            if (class_exists('\Magento\TargetRule\Block\Catalog\Product\ProductList\Related')) {
                $content = "{{block class=\"Magento\TargetRule\Block\Catalog\Product\ProductList\Related\" 
                name=\"catalog.product.related\" type=\"related-rule\" 
                template=\"Magento_Catalog::product/list/items.phtml\" }}";
            } else {
                $content = "{{block class=\"Magento\Catalog\Block\Product\ProductList\Related\" 
                name=\"catalog.product.related\" type=\"related\" 
                template=\"Magento_Catalog::product/list/items.phtml\" }}";
            }

        } else {
            $content = "";
        }
        return $content;
    }

    /**
     * Get Upsell Product Content
     *
     * @param int $upsellContent
     * @return string
     */
    public function getUpsellProductContent($upsellContent)
    {

        if ($upsellContent) {
            if (class_exists('\Magento\TargetRule\Block\Catalog\Product\ProductList\Upsell')) {
                $content = "{{block class=\"Magento\TargetRule\Block\Catalog\Product\ProductList\Upsell\" 
                name=\"product.info.upsell\" type=\"upsell-rule\" 
                template=\"Magento_Catalog::product/list/items.phtml\" }}";
            } else {
                $content = "{{block class=\"Magento\Catalog\Block\Product\ProductList\Upsell\" 
                name=\"product.info.upsell\" type=\"upsell\" 
                template=\"Magento_Catalog::product/list/items.phtml\" }}";
            }
        } else {
            $content = "";
        }
        return $content;
    }

    /**
     * Get Crosssell Product Content
     *
     * @param int $crosssellContent
     * @return string
     */
    public function getCrosssellProductContent($crosssellContent)
    {
        if ($crosssellContent) {
            if (class_exists('\Magento\TargetRule\Block\Product\AbstractProduct')) {
                $content = "{{block class=\"Bss\ProductCustomTabs\Block\Crosssell\"
                name=\"product.info.upsell\" type=\"crosssell-rule\" 
                template=\"Magento_Catalog::product/list/items.phtml\" }}";
            } else {
                $content = "{{block class=\"Magento\Catalog\Block\Product\ProductList\Crosssell\"
                name=\"product.info.upsell\" type=\"crosssell\" 
                template=\"Magento_Catalog::product/list/items.phtml\" }}";
            }
        } else {
            $content = "";
        }
        return $content;
    }

    /**
     * Edit Content Tab
     * @param string $content
     * @return string
     * @throws \Exception
     */
    public function editTabContent($content)
    {
        $content = $this->filterProvider->getPageFilter()->filter($content);
        return $content;
    }
}
