<?php
/**
 * BSS Commerce Co.
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the EULA
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://bsscommerce.com/Bss-Commerce-License.txt
 *
 * @category   BSS
 * @package    Bss_ProductCustomTabs
 * @author     Extension Team
 * @copyright  Copyright (c) 2017-2018 BSS Commerce Co. ( http://bsscommerce.com )
 * @license    http://bsscommerce.com/Bss-Commerce-License.txt
 */
namespace Bss\ProductCustomTabs\Model;

use Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

class DataProvider extends \Magento\Ui\DataProvider\AbstractDataProvider
{

    /**
     * Data Provider name
     *
     * @var string $name
     */
    protected $name;

    /**
     * Data Provider Primary Identifier name
     *
     * @var string $primaryFieldName
     */
    protected $primaryFieldName;

    /**
     * Data Provider Request Parameter Identifier Name
     *
     * @var string $requestFieldName
     */
    protected $requestFieldName;

    /**
     * Meta Array
     * @var array $meta
     */
    protected $meta = [];

    /**
     * Provider configuration data
     *
     * @var array $data
     */
    protected $data = [];

    /**
     * Abstract Collection
     *
     * @var AbstractCollection $collection
     */
    protected $collection;

    /**
     * DataProvider constructor.
     *
     * @param string $name
     * @param string $primaryFieldName
     * @param string $requestFieldName
     * @param array $meta
     * @param array $data
     *
     * @return void
     */
    public function __construct(
        $name,
        $primaryFieldName,
        $requestFieldName,
        array $meta = [],
        array $data = []
    ) {
        parent::__construct(
            $name,
            $primaryFieldName,
            $requestFieldName,
            $meta,
            $data
        );
    }

    /**
     * Get data
     *
     * @return array
     */
    public function getData()
    {
        return [];
    }
}
